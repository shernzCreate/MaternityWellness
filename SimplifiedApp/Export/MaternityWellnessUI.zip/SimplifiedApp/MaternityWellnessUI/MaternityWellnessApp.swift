import SwiftUI

@main
struct MaternityWellnessApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
